$(window).load(function () {
    //Add the required UI logic here
    //For example, you can catch the HTML element ID and change the content etc.
});

